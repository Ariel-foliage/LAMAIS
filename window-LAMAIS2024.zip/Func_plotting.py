
def plot(df_spectrum, df_l, folder_output, name_sample):
    import pandas as pd
    import plotly.graph_objects as go
    import plotly.express as px
    from ast import literal_eval
    import os

    # 步骤1：按照 peak index 分组，找到每个位置的 pearson 最大的化合物
    df_lamais = df_l.drop(df_l[df_l['cluster']=='singlet'].index)
    df_lamais['peak index'] = df_lamais['peak index'].astype(int)
    df_lamais['pearson'] = df_lamais['pearson'].astype(float)
    max_pearson_compounds = df_lamais.loc[df_lamais.groupby('peak index')['pearson'].idxmax()]

    # 步骤2：存储每个位置的 pearson 最大化合物信息以及其他化合物信息

    compound_info = {}
    for index, row in df_lamais.iterrows():
        peak_index = row['peak index']
        cpd_name = row['name for presentation']
        pearson = row['pearson']
        if peak_index not in compound_info: # 如果该条目尚不存在，则初始化字典的格式
            compound_info[peak_index] = {'compound': cpd_name, 'pearson': round(pearson,3), 'labels': []}
        else:
            pass

        if index not in max_pearson_compounds.index:
            compound_info[peak_index]['labels'].append(cpd_name) 
        else:
            compound_info[peak_index]['compound']=cpd_name
            compound_info[peak_index]['pearson']=round(pearson,3)       

    # # 调试用输出
    # compound_info_df = pd.DataFrame.from_dict(compound_info, orient='index')
    # compound_info_df.to_excel('./compound_info.xlsx', index_label='Index')  

    # 步骤3：将谱图数据与化合物信息合并，进行可视化
    # 颜色映射：为显示标记的化合物定义不同颜色
    # 连续颜色
    # px.colors.sequential.swatches_continuous()
    # 非连续
    # px.colors.qualitative.swatches()
    colormap = px.colors.qualitative.Alphabet
    max_pearson_cpd_ls = max_pearson_compounds['name for presentation'].unique().tolist()
    if len(colormap) >= len(max_pearson_cpd_ls):    
        c_mapping = dict(zip(max_pearson_cpd_ls,colormap[0:len(max_pearson_cpd_ls)]))
    else:
        # 如果色卡不够用了，就将colormap加长
        colormap = px.colors.qualitative.Light24 + px.colors.qualitative.Alphabet
        c_mapping = dict(zip(max_pearson_cpd_ls,colormap[0:len(max_pearson_cpd_ls)]))


    # 绘制谱图
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df_spectrum['shift'], 
        y=df_spectrum['intensity'], 
        mode='lines', 
        name='Spectrum',
        line=dict(color='#696969'),
        showlegend=False))

    for cpd in max_pearson_cpd_ls:
        color_cpd = c_mapping[cpd]  # 获取当前化合物的颜色
        # 整理当前化合物的信息
        data_cpd = {peak_index: info for peak_index, info in compound_info.items() if info['compound'] == cpd}
        # 绘制当前化合物的独立 trace
        peak_indexes = list(data_cpd.keys()) # 化合物对应的所有峰索引
        trace = go.Scatter(
            x=df_spectrum.loc[peak_indexes, 'shift'] ,
            y=df_spectrum.loc[peak_indexes, 'intensity'],
            mode='markers',
            name=cpd,
            marker=dict(color=color_cpd, size=10,line=dict(width=2,color='#c80000')),
            text=f"{cpd}",
            showlegend=True
        )
        fig.add_trace(trace)

        for ind,info in data_cpd.items():
            if info['labels'] != []:
                y_position = df_spectrum.loc[ind, 'intensity']+3
                # 转换十六进制颜色代码为RGB颜色代码
                rgb_color_cpd = px.colors.hex_to_rgb(color_cpd)
                # 构造RGBA颜色代码
                marker_color = f"rgba({rgb_color_cpd[0]}, {rgb_color_cpd[1]}, {rgb_color_cpd[2]}, 0.5)"
                for label in info['labels']:
                    trace_l = go.Scatter(
                        x=[df_spectrum.loc[ind, 'shift']],
                        y=[y_position],
                        mode='markers',
                        marker=dict(color=marker_color, size=11),
                        text=f"Candidate:{label}",
                        showlegend=False
                        )
                    fig.add_trace(trace_l)
                    y_position+=3
            else:
                pass   
        


    ######################################################
    # 单峰化合物部分
    df_s = df_l.loc[df_l['cluster']=='singlet']
    # colormap_s = px.colors.qualitative.Plotly
    cpd_s_ls = df_s['name for presentation'].values.tolist()
    c_mapping_s = dict(zip(cpd_s_ls,colormap[0:len(cpd_s_ls)]))

    # 分离线段和点的数据
    df_seg = df_s[df_s['peak index'].apply(lambda x: isinstance(x, str))]
    df_point = df_s[df_s['peak index'].apply(lambda x: isinstance(x, int))]

    # 绘制线段
    for index, row in df_seg.iterrows():
        cpd_s = row['name for presentation']
        shift_start, shift_end = literal_eval(row['peak'])
        trace_seg = go.Scatter(
            x=[shift_start, shift_end],
            y=[0, 0],
            mode='lines',
            name=f"{cpd_s}",
            text=f"{cpd_s}",
            line=dict(color=c_mapping_s[cpd_s], width=3),
            showlegend=True
        )
        fig.add_trace(trace_seg)

    # 绘制点
    for index, row in df_point.iterrows():
        cpd_s = row['name for presentation']
        peak_index = row['peak index']
        trace_point = go.Scatter(
            x=[df_spectrum.loc[peak_index, 'shift']],
            y=[df_spectrum.loc[peak_index, 'intensity']],
            mode='markers',
            marker=dict(symbol='triangle-up', color=c_mapping_s[cpd_s], size=10,line=dict(width=2,color='#0000CD')),
            name=f"{cpd_s}",
            text=f"{cpd_s}",
            showlegend=True
        )
        fig.add_trace(trace_point)

    # 设置图形布局和标签
    fig.update_xaxes(range=[10.0,-0.5])
    fig.update_layout(title=f"Spectral profiling for {name_sample}",
                    xaxis=dict(title= 'Chemical Shift (f1)',zeroline= False,ticks='inside',linewidth=1.5,tickwidth=1.5),
                    yaxis=dict(title= 'Intensity',zeroline=False,ticks="",showticklabels=False,linewidth=1.5),
                    template='simple_white',
                    height=900,
                    width=1500)

    ###########################
    result_file_path = os.path.join(folder_output,f"./plot-{name_sample}.html")
    fig.write_html(result_file_path)    

    # return result_file_path