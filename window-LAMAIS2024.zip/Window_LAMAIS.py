# !/usr/bin/env python3
# -*- coding=utf-8 -*-

import tkinter as tk
from tkinter import filedialog, scrolledtext
from tkinter import Button, Label, Entry
import pandas as pd
from glob import glob
import os
# import plotly.express as px
# import plotly.graph_objects as go
from Func_LAMAIS import lamais
from Func_plotting import plot

class LAMAIS:
    def __init__(self, master):
        self.master = master
        self.master.title("LAMAIS")

        self.create_widgets()

    def create_widgets(self):
        # Input
        self.input_label = Label(self.master, text="Select the input folder:")
        self.input_label.grid(row=0, column=0, pady=10, padx=10, sticky=tk.W)
        self.input_path_var = tk.StringVar()
        self.input_entry = Entry(self.master, textvariable=self.input_path_var, width=40)
        self.input_entry.grid(row=0, column=1, pady=10, padx=10, columnspan=2, sticky=tk.W)
        self.input_browse_button = Button(self.master, text="Browse", command=self.browse_input_folder)
        self.input_browse_button.grid(row=0, column=3, pady=10, padx=10, sticky=tk.W)

        # Output
        self.output_label = Label(self.master, text="Select the output folder:")
        self.output_label.grid(row=1, column=0, pady=10, padx=10, sticky=tk.W)
        self.output_path_var = tk.StringVar()
        self.output_entry = Entry(self.master, textvariable=self.output_path_var, width=40)
        self.output_entry.grid(row=1, column=1, pady=10, padx=10, columnspan=2, sticky=tk.W)
        self.output_browse_button = Button(self.master, text="Browse", command=self.browse_output_folder)
        self.output_browse_button.grid(row=1, column=3, pady=10, padx=10, sticky=tk.W)

        # Similarity threshold
        self.threshold_label = Label(self.master, text="Similarity threshold:")
        self.threshold_label.grid(row=2, column=0, pady=10, padx=10, sticky=tk.W)
        self.threshold_var = tk.DoubleVar(value=0.8)
        self.threshold_entry = Entry(self.master, textvariable=self.threshold_var, width=10)
        self.threshold_entry.grid(row=2, column=1, pady=10, padx=10, sticky=tk.W)

        # Similarity threshold
        self.threshold_label = Label(self.master, text="Similarity threshold:")
        self.threshold_label.grid(row=2, column=0, pady=10, padx=10, sticky=tk.W)
        self.threshold_var = tk.DoubleVar(value=0.8)
        self.threshold_entry = Entry(self.master, textvariable=self.threshold_var, width=10)
        self.threshold_entry.grid(row=2, column=1, pady=10, padx=10, sticky=tk.W)

        # Button for Advanced mode
        self.advanced_button = Button(self.master, text="Advanced mode", command=self.toggle_advanced_mode)
        self.advanced_button.grid(row=3, column=2, pady=10, padx=10, sticky=tk.W)

        # δr -- input for advanced users
        self.delta_r_label = Label(self.master, text="δr (ppm):")
        self.delta_r_label.grid(row=3, column=0, pady=10, padx=10, sticky=tk.W)
        self.delta_r_var = tk.DoubleVar(value=0.1)
        self.delta_r_entry = Entry(self.master, textvariable=self.delta_r_var, width=10, state='disabled')
        self.delta_r_entry.grid(row=3, column=1, pady=10, padx=10, sticky=tk.W)

        # Submit
        self.submit_button = Button(self.master, text="Submit", command=self.run_analysis)
        self.submit_button.grid(row=4, column=0, pady=20, padx=10, columnspan=4)

        # Result display
        self.result_display = scrolledtext.ScrolledText(self.master, width=50, height=10)
        self.result_display.grid(row=5, column=0, pady=10, padx=10, columnspan=4)


    def browse_input_folder(self):
        # Set relative path
        folder_path = filedialog.askdirectory(initialdir='./') 
        # initialdir参数指定了对话框打开时默认显示的文件夹，这里设置为脚本所在文件夹。
        if folder_path:
            relative_path = os.path.relpath(folder_path, './')
            self.input_path_var.set(relative_path)

    def browse_output_folder(self):
        # Set relative path
        folder_path = filedialog.askdirectory(initialdir='./')
        if folder_path:
            relative_path = os.path.relpath(folder_path, './')
            self.output_path_var.set(relative_path)

    def toggle_advanced_mode(self):
        if self.delta_r_entry['state'] == 'disabled':
            self.delta_r_entry['state'] = 'normal'
        else:
            self.delta_r_entry['state'] = 'disabled'            
  
    def run_analysis(self):
        # Gets the path and threshold entered by the user
        input_folder = self.input_path_var.get()
        output_folder = self.output_path_var.get()
        threshold = self.threshold_var.get()
        delta_r = self.delta_r_var.get()  # Get the value of δr         
        # print("Input Folder:", input_folder)  # Debugging output
        # print("Output Folder:", output_folder)  # Debugging output

        # Call the function of LAMAIS
        sample_files = glob(os.path.join(input_folder, "*.csv"))
        # print("Sample Files:", sample_files) # Debugging output
        result_texts = []

        for file_path in sample_files: # !!! 此处的file_path已经是单个文件了
            # print("Reading file:", file_path)  # Debugging output
            if os.path.exists(file_path):
                print(f"File {file_path} exists.")
            else:
                print(f"File {file_path} does not exist!")            
            
            df_spectrum, df_l, result_text = lamais(file_path, output_folder, threshold, delta_r) 
            result_texts.append(result_text)

            # Call the PLOT function
            name_sample = os.path.splitext(os.path.basename(file_path))[0]
            plot(df_spectrum, df_l, output_folder, name_sample)            

        # Display the text results in the results display box
        self.result_display.delete(1.0, tk.END)  # Clear the previous content
        self.result_display.insert(tk.END, "\n".join(result_texts))

if __name__ == "__main__":
    root = tk.Tk()
    app = LAMAIS(root)
    root.mainloop()



