# !/usr/bin/env python3
# -*- coding=utf-8 -*-

def lamais(file_path, output_folder, threshold, delta_r):
    import numpy as np
    import pandas as pd
    import os
    from scipy import stats,interpolate
    import re
    from glob import glob
    import nmrglue as ng


    p_cas = re.compile(r"./templates\\(\S*).csv")
    files_template = glob('./templates/*.csv')
    s_df = pd.read_excel('./templates/singlet.xlsx')
    df_lib = pd.read_excel('./templates/LibraryList_LAMAIS.xlsx')

    rw = delta_r
    col_output = ['peak','cpd name','cluster','pearson','peak index']
    
    ls_df_out = []
    name_sample = os.path.splitext(os.path.basename(file_path))[0] # Extract the sample file name without extension
    df_sample = pd.read_csv(file_path,delim_whitespace=True, header=0, names=['shift','intensity']) * 1 # Read sample spectrum
    df_sample = df_sample.dropna()
    df_sample = df_sample.reset_index(drop=True)

    step = (df_sample['shift'].max() - df_sample['shift'].min())/df_sample.shape[0]
    step = format(step,'.4f')
        
    # Set baseline for SNR (0.2,0.6)
    mask = (0.2 <= df_sample.iloc[:,0]) & (df_sample.iloc[:,0] <= 0.6)
    data_bl = df_sample.loc[mask]
    max_ = np.max(data_bl.iloc[:, -1])
    min_ = np.min(data_bl.iloc[:, -1])
    bl = max_-min_    
    

    for file_t in files_template:
        df_template = pd.read_csv(file_t, header=0) # Read template data
        name_cas = p_cas.match(file_t).group(1) 
        clu_met = [] 
        clu_peak_out = [] 

        clusters = df_template['cluster'].dropna().unique()
        clusters.sort() 

        for c in clusters:            
            counts = 0                                    
            clu_name = c                        
            clu_data = df_template[df_template['cluster']==c]
            clu_peaks = int(np.unique(clu_data['peaks'])[0])
            # spline
            clu_start = clu_data.iloc[0,0]
            clu_end = clu_data.iloc[-1,0]
            # !!! Verification for range ########################
            sample_start = df_sample.iloc[0,0]
            sample_end = df_sample.iloc[-1,0]
            if (clu_end+rw) > sample_end or (clu_start-rw) < sample_start:
                break 
            else: 
                pass
            ##################################################################
            clu_sx = np.arange(clu_start, clu_end, float(step))
            clu_func = interpolate.UnivariateSpline(clu_data['shift'],clu_data['A'],s=0)
            clu_sy = clu_func(clu_sx)                   
            windowlen = len(clu_sy)
            window_aim = df_sample[(df_sample['shift'] <= (clu_end + rw)) & (df_sample['shift'] >= (clu_start-rw))] 
        
            peaks = ng.peakpick.pick(data=window_aim.iloc[:,-1].values,algorithm='thres',msep=5,pthres=bl*3,table=False, est_params=False, cluster=False)
            # Determine whether to start rolling
            if len(peaks) == 0:
                if clu_name == 'c1':
                    if window_aim.iloc[:,-1].values.max() >= 3*bl:
                        continue # Move on to next cluster
                    else:
                        break
                else:
                    pass # cpd is not in the sample
            elif 0 < len(peaks) < clu_peaks:                
                continue # Move on to next cluster   
            elif len(peaks) >= clu_peaks:                
                # rolling ##########################################                            
                rolling = window_aim.rolling(windowlen, step = 3)      
                out_r = [] 
                for r_ in rolling:                                                     
                    if len(r_) == windowlen:
                        pi = stats.pearsonr(clu_sy,r_.iloc[:,-1].values)[0]
                        if pi > threshold:
                            r_index = r_.index.to_list()
                            out_r.append([pi,r_index[0],r_index[-1]]) 
                            counts = counts + 1
                        else:
                            pass
                    else:
                        pass
                
            # rolling completed            
            if counts > 0:
                out_r_df = pd.DataFrame(out_r)
                out_r_max = out_r_df[out_r_df.iloc[:,0] == out_r_df.iloc[:,0].max()] 
                for p_ in peaks:
                    p_index = p_[0] + window_aim.index.to_list()[0]
                    if (p_index>=out_r_max.iloc[0,1]) & (p_index<=out_r_max.iloc[0,2]):
                        clu_peak_out.append([format(df_sample.loc[p_index,'shift'],'.4f'), name_cas, clu_name, out_r_max.iloc[0,0], p_index])
                    else:
                        pass                
                clu_met.append(clu_name) 
            else:
                pass
        
        # Determine whether to output
        if len(clu_met) >= 1: 
            df_clus_out = pd.DataFrame(clu_peak_out)
            ls_df_out.append(df_clus_out)
        elif len(clu_met) == 0:
            continue 

    # Single peak compounds ##########################################################################################
    s_out = []
    for i in range(0,s_df.shape[0]):
        name_cas = s_df.iloc[i,0]
        shift_s = s_df.iloc[i,1]
        window_s = df_sample[(df_sample['shift'] <= (shift_s+rw)) & (df_sample['shift'] >= (shift_s-rw))] 
        peak_s = ng.peakpick.pick(data=window_s.iloc[:,-1].values,algorithm='thres',msep=5,pthres=bl*5,table=False, est_params=False, cluster=False)
        
        if len(peak_s) == 1:
            s_index = peak_s[0][0] + window_s.index.to_list()[0]            
            s_out.append([format(df_sample.loc[s_index,'shift'],'.4f'),name_cas,'singlet','-',s_index])
        elif len(peak_s) < 1:
            pass
        elif len(peak_s) > 1:
            s_range = '[{},{}]'.format((shift_s-rw),(shift_s+rw))
            s_out.append([s_range, name_cas,'singlet','-','-'])

    if len(s_out)>0:
        df_s_out = pd.DataFrame(s_out)
        ls_df_out.append(df_s_out)
    else:
        pass
    
    # Output #############################################  
    if len(ls_df_out) >= 1:     
        df_out = pd.concat(ls_df_out,ignore_index=True)
        df_out.columns = col_output
        # Match name of cpd
        name_out = []
        cas = df_out['cpd name'].values
        for cas_ in cas:
            name_eng = df_lib[df_lib['cas']==cas_].iat[0,1]
            name_out.append(name_eng)
        df_out.insert(2,'name for presentation',name_out)
        
        result_file_path = os.path.join(output_folder, f"profiling_{name_sample}.xlsx")
        df_out.to_excel(result_file_path, index=False)
        result_text = f"{name_sample} is processed"
    else:
        result_text = f"{name_sample} no matching"
    
    return df_sample, df_out, result_text
        




